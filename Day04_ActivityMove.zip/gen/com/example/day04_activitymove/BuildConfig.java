/** Automatically generated file. DO NOT MODIFY */
package com.example.day04_activitymove;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
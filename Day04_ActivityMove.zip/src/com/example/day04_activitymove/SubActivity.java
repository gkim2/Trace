package com.example.day04_activitymove;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SubActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_sub);
		
		Intent intent = getIntent();
		String msg = intent.getStringExtra("msg");
		
		//activity_syb.xml 로 전개된 TextView 의 참조값 얻어오기
		TextView result = (TextView)findViewById(R.id.result);
		//문자열 출력하기
		result.setText(msg);
	}
	
		//종료버튼을 눌렀을때 호출되는 메소드
		public void end(View v){
			//현재 액티비티 저장하기
			finish();
		}

}

